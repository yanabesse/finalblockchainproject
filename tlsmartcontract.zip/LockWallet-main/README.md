# LockWallet
User is able to deposit a specified amount of ETH, to be locked up for a certain specified time period
